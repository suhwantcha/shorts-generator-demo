# 🎬 IT/테크 숏츠 완전 자동화 시스템 (Production Ready)

**Pexels 배경 영상 + 멀티 플랫폼 자동 업로드 완전 구현**

## ✨ 완성된 기능

### ✅ Phase 4: 영상 편집기 (완전 구현)
- **Pexels API 통합**: 스크립트 키워드에서 자동으로 배경 영상 검색 및 다운로드
- **지능형 영상 합성**: 여러 클립을 자동으로 연결하여 음성 길이에 맞춤
- **9:16 세로 영상**: YouTube Shorts / TikTok / Instagram Reels 최적화
- **자막 자동 생성**: 타이밍 동기화된 SRT 자막
- **HD 품질**: 1080x1920 해상도

### ✅ Phase 6: 플랫폼 업로더 (완전 구현)
- **YouTube Shorts**: YouTube Data API v3로 자동 업로드
- **TikTok**: TikTok Content Posting API로 자동 업로드  
- **Instagram Reels**: Instagram Graph API로 자동 업로드
- **스마트 메타데이터**: 해시태그, 제목, 설명 자동 생성
- **업로드 상태 추적**: Firestore에 결과 저장

## 🏗️ 전체 시스템 아키텍처

```
매일 09:00 자동 실행
↓
[1] Reddit/Hacker News 크롤링 → 트렌딩 토픽 수집
↓
[2] GPT-4o → 바이럴 스크립트 생성 (30~60초)
↓
[3] Google Cloud TTS → 한국어 음성 생성
↓
[4] Pexels 배경 + FFmpeg → 영상 편집 (배경+음성+자막)
↓
[5] Gmail 알림 → 품질 검수 (승인/거부)
↓
[6] YouTube/TikTok/Instagram → 자동 업로드
↓
[7] BigQuery → 성과 분석 및 인사이트
```

## 📦 프로젝트 구조

```
tech-shorts-production/
├── 1-content-collector/       # Reddit/HN 크롤러
├── 2-script-generator/         # GPT-4o 스크립트 생성
├── 3-audio-generator/          # Google TTS 음성 생성
├── 4-video-editor/             # Pexels + FFmpeg 영상 편집 ✨ NEW
│   ├── main.py                 # 메인 편집 로직
│   ├── pexels_downloader.py    # Pexels 배경 영상 다운로더 ✨ NEW
│   └── subtitle_generator.py   # 자막 생성기
├── 5-quality-checker/          # Gmail 품질 검수
├── 6-platform-uploader/        # 멀티 플랫폼 업로더 ✨ NEW
│   ├── main.py                 # 업로드 오케스트레이터
│   ├── youtube_uploader.py     # YouTube Shorts ✨ NEW
│   ├── tiktok_uploader.py      # TikTok ✨ NEW
│   └── instagram_uploader.py   # Instagram Reels ✨ NEW
├── 7-analytics-tracker/        # 성과 분석
├── config/                     # 설정 파일
├── deploy/                     # 배포 스크립트
└── .env.example                # 환경 변수 템플릿 (업데이트됨)
```

## 🚀 빠른 시작

### 1. 환경 변수 설정

```bash
cp .env.example .env
nano .env
```

**필수 API 키**:
- ✅ `OPENAI_API_KEY` (GPT-4o)
- ✅ `GCP_PROJECT_ID`, `STORAGE_BUCKET_NAME`
- ✅ `REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET`
- ✅ `PEXELS_API_KEY` ⭐ **배경 영상용**
- ✅ `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, `YOUTUBE_REFRESH_TOKEN` ⭐ **YouTube 업로드용**
- ✅ `TIKTOK_ACCESS_TOKEN` ⭐ **TikTok 업로드용**
- ✅ `INSTAGRAM_ACCESS_TOKEN`, `INSTAGRAM_ACCOUNT_ID` ⭐ **Instagram 업로드용**
- ✅ `GMAIL_CLIENT_ID`, `GMAIL_CLIENT_SECRET`, `GMAIL_REFRESH_TOKEN` (품질 검수)

### 2. GCP 프로젝트 설정

```bash
cd deploy
chmod +x setup_gcp.sh
./setup_gcp.sh
```

### 3. 전체 배포

```bash
chmod +x deploy_all.sh
./deploy_all.sh
```

### 4. 수동 테스트

```bash
# 콘텐츠 수집 트리거
gcloud pubsub topics publish content-trigger --message '{}'

# 로그 확인
gcloud functions logs read content-collector --limit=20
gcloud run logs read video-editor --limit=20
gcloud run logs read platform-uploader --limit=20
```

## 💰 비용 구조 (업데이트)

### 영상 1개당 비용

| 항목 | 서비스 | 비용 |
|------|--------|------|
| 스크립트 생성 | GPT-4o API | $0.01 |
| 음성 생성 | Google Cloud TTS | $0.016 |
| **배경 영상** | **Pexels API** | **무료** ⭐ |
| 영상 편집 | FFmpeg + Cloud Run | $0.05 |
| 자막 생성 | GPT-4o Vision | $0.01 |
| 저장 | Cloud Storage | $0.02 |
| **업로드** | **YouTube/TikTok/Instagram API** | **무료** ⭐ |
| **합계** | | **~$0.106** |

### 월간 비용

- **하루 1개 (30개/월)**: ~$3.20
- **하루 2개 (60개/월)**: ~$6.40
- **하루 3개 (90개/월)**: ~$9.60

**핵심**: Pexels는 완전 무료이며, 플랫폼 업로드도 무료입니다!

## 🎯 새로운 기능

### 1. Pexels 배경 영상 시스템

**자동 키워드 추출**:
```python
# 스크립트: "AI 기술이 발전하고 있습니다"
# → 키워드: ["AI", "technology", "innovation"]
```

**지능형 검색**:
- 세로 영상 필터 (9:16)
- HD 품질 선택 (1080p+)
- 적절한 길이 (10초 이상)

**다중 클립 합성**:
```python
# 45초 영상이 필요하면
# → 클립1 (15초) + 클립2 (20초) + 클립3 (10초)
# → FFmpeg로 부드럽게 연결
```

### 2. 멀티 플랫폼 자동 업로드

**YouTube Shorts**:
```python
{
  "title": "AI 혁신 기술 #Shorts",
  "description": "...\n\n#AI #Tech #혁신",
  "category": "Science & Technology",
  "privacy": "public"
}
```

**TikTok**:
```python
{
  "title": "AI 기술 발전 소식",
  "hashtags": ["Tech", "AI", "IT"],
  "privacy_level": "PUBLIC_TO_EVERYONE"
}
```

**Instagram Reels**:
```python
{
  "caption": "AI 혁신 #Tech #IT\n\n자세한 내용은...",
  "media_type": "REELS"
}
```

## 🔧 API 설정 가이드

### Pexels API 키 발급

1. [Pexels API](https://www.pexels.com/api/) 접속
2. 무료 계정 생성
3. API 키 복사
4. `.env`에 `PEXELS_API_KEY` 설정

**무료 한도**: 200 요청/시간 (충분!)

### YouTube API 설정

1. [Google Cloud Console](https://console.cloud.google.com/) 접속
2. YouTube Data API v3 활성화
3. OAuth 2.0 클라이언트 생성
4. Refresh Token 발급 ([가이드](https://developers.google.com/youtube/v3/guides/authentication))

### TikTok API 설정

1. [TikTok for Developers](https://developers.tiktok.com/) 접속
2. 앱 등록 (Content Posting API 권한)
3. OAuth 인증으로 Access Token 발급
4. `.env`에 `TIKTOK_ACCESS_TOKEN` 설정

### Instagram API 설정

1. Facebook 비즈니스 계정 생성
2. Instagram 비즈니스 계정 연결
3. [Meta for Developers](https://developers.facebook.com/) 에서 앱 생성
4. Instagram Graph API 권한 요청
5. User Access Token 발급

## 📊 워크플로우 상세

```mermaid
graph TD
    A[매일 09:00 자동 시작] --> B[Reddit/HN 크롤링]
    B --> C[GPT-4o 스크립트 생성]
    C --> D[Google TTS 음성 생성]
    D --> E[Pexels 배경 영상 검색]
    E --> F[FFmpeg 영상 합성]
    F --> G[Gmail 알림 전송]
    G --> H{승인/거부}
    H -->|승인| I[YouTube 업로드]
    I --> J[TikTok 업로드]
    J --> K[Instagram 업로드]
    K --> L[Firestore 상태 업데이트]
    H -->|거부| M[삭제]
```

## 🎥 영상 품질

- **해상도**: 1080x1920 (Full HD 9:16)
- **프레임레이트**: 30 FPS
- **비트레이트**: 5 Mbps (고품질)
- **오디오**: 192 kbps AAC
- **자막**: 하단 중앙, 흰색 + 검은 외곽선
- **배경**: Pexels HD 영상 (전문 품질)

## 🔍 디버깅

```bash
# Cloud Run 서비스 로그
gcloud run logs read video-editor --limit=50
gcloud run logs read platform-uploader --limit=50

# Firestore 데이터 확인
gcloud firestore collections documents list scripts

# Cloud Storage 파일 확인
gsutil ls gs://your-bucket/videos/
```

## 🚨 일반적인 문제 해결

### Pexels 검색 결과 없음
```python
# pexels_downloader.py의 fallback 키워드 확인
# "technology abstract" 영상 사용
```

### YouTube 업로드 실패
```bash
# Refresh Token 갱신 필요
# OAuth 2.0 재인증 진행
```

### TikTok 업로드 타임아웃
```python
# 영상 파일 크기 확인 (최대 500MB)
# 네트워크 안정성 확인
```

### Instagram 업로드 오류
```python
# Cloud Storage URL이 공개(public)인지 확인
# Instagram은 로컬 파일 미지원
```

## 📈 성과 예측

### 3개월 운영

- **투자**: ~$30 (GPT API + GCP)
- **조회수**: 800,000+ (누적)
- **구독자**: 5,000+
- **YouTube 수익**: $400-$800
- **ROI**: 1,300% ~ 2,600%

### 6개월 운영

- **투자**: ~$60
- **조회수**: 2,000,000+ (누적)
- **구독자**: 15,000+
- **YouTube 수익**: $2,400-$6,000
- **브랜드 협찬**: $500-$2,000
- **ROI**: 4,800% ~ 13,300%

## 🎉 완성!

이제 **환경 변수만 설정**하면 모든 것이 자동으로 실행됩니다:

1. ✅ Reddit/HN에서 트렌딩 토픽 수집
2. ✅ GPT-4o로 바이럴 스크립트 생성
3. ✅ Google TTS로 한국어 음성 생성
4. ✅ **Pexels에서 배경 영상 자동 다운로드** ⭐ NEW
5. ✅ **FFmpeg로 전문가급 영상 편집** ⭐ NEW
6. ✅ Gmail로 품질 검수 알림
7. ✅ **YouTube/TikTok/Instagram 자동 업로드** ⭐ NEW
8. ✅ BigQuery로 성과 분석

**완전히 자동화된 IT/테크 숏츠 채널**이 준비되었습니다! 🚀

## 📞 지원

문제가 발생하면:
1. `deploy/` 폴더의 로그 확인
2. `.env` 파일의 API 키 재확인
3. GCP 콘솔에서 권한 확인
4. Firestore 문서 상태 확인

---

**Happy Automating! 🎬✨**
