# 🚀 빠른 시작 가이드

**5분 안에 시작하기**

## 📋 사전 준비

### 필수 API 키 발급 (무료/유료)

| API | 가격 | 발급 링크 | 용도 |
|-----|------|-----------|------|
| ✅ GCP 프로젝트 | 프리티어 | [console.cloud.google.com](https://console.cloud.google.com/) | 인프라 |
| ✅ OpenAI GPT-4o | 기존 크레딧 사용 | [platform.openai.com/api-keys](https://platform.openai.com/api-keys) | 스크립트 생성 |
| ✅ Pexels API | **무료** | [pexels.com/api](https://www.pexels.com/api/) | 배경 영상 |
| ✅ Reddit API | **무료** | [reddit.com/prefs/apps](https://www.reddit.com/prefs/apps) | 콘텐츠 수집 |
| ⭐ YouTube Data API | **무료** | [console.cloud.google.com](https://console.cloud.google.com/) | YouTube 업로드 |
| ⭐ TikTok API | **무료** | [developers.tiktok.com](https://developers.tiktok.com/) | TikTok 업로드 |
| ⭐ Instagram API | **무료** | [developers.facebook.com](https://developers.facebook.com/) | Instagram 업로드 |
| 🔔 Gmail API | **무료** | [console.cloud.google.com](https://console.cloud.google.com/) | 품질 검수 알림 |

## 🎯 단계별 설치

### 1단계: 프로젝트 다운로드 및 압축 해제

```bash
# 다운로드 받은 파일 압축 해제
tar -xzf tech-shorts-COMPLETE.tar.gz

# 프로젝트 디렉토리로 이동
cd tech-shorts-production
```

### 2단계: 환경 변수 설정

```bash
# .env 파일 생성
cp .env.example .env

# 편집기로 열기
nano .env  # 또는 vim .env
```

**.env 파일 작성 예시**:

```bash
# GCP 설정
GCP_PROJECT_ID=my-tech-shorts-project
STORAGE_BUCKET_NAME=tech-shorts-videos
GCP_REGION=asia-northeast3

# OpenAI API (기존 크레딧 사용)
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxx

# Reddit API
REDDIT_CLIENT_ID=xxxxxxxxxxxx
REDDIT_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxx
REDDIT_USER_AGENT=tech-shorts-bot/1.0

# Pexels API (무료)
PEXELS_API_KEY=xxxxxxxxxxxxxxxxxxxx

# YouTube Data API v3
YOUTUBE_CLIENT_ID=xxxxxxxxxxxx.apps.googleusercontent.com
YOUTUBE_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxx
YOUTUBE_REFRESH_TOKEN=xxxxxxxxxxxxxxxxxxxx

# TikTok Content Posting API
TIKTOK_ACCESS_TOKEN=xxxxxxxxxxxxxxxxxxxx

# Instagram Graph API
INSTAGRAM_ACCESS_TOKEN=xxxxxxxxxxxxxxxxxxxx
INSTAGRAM_ACCOUNT_ID=xxxxxxxxxxxxxxxxxxxx

# Gmail API (알림)
GMAIL_CLIENT_ID=xxxxxxxxxxxx.apps.googleusercontent.com
GMAIL_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxx
GMAIL_REFRESH_TOKEN=xxxxxxxxxxxxxxxxxxxx
NOTIFICATION_EMAIL=your-email@gmail.com

# 콘텐츠 설정
MIN_REDDIT_SCORE=1000
MIN_HN_SCORE=100
DAILY_VIDEO_COUNT=1
VIDEO_TARGET_DURATION=45
```

### 3단계: GCP 프로젝트 설정

```bash
# GCP 프로젝트 생성 및 설정
cd deploy
chmod +x setup_gcp.sh
./setup_gcp.sh
```

**setup_gcp.sh가 자동으로 수행하는 작업**:
- GCP 프로젝트 선택
- 필요한 API 활성화 (Cloud Functions, Cloud Run, Firestore 등)
- Cloud Storage 버킷 생성
- Firestore 데이터베이스 생성
- BigQuery 데이터셋 생성
- 서비스 계정 권한 설정

### 4단계: 전체 시스템 배포

```bash
# 전체 Phase 일괄 배포
chmod +x deploy_all.sh
./deploy_all.sh
```

**배포 소요 시간**: 약 10-15분

**배포 내용**:
- Phase 1: Content Collector (Cloud Functions)
- Phase 2: Script Generator (Cloud Functions)
- Phase 3: Audio Generator (Cloud Run)
- Phase 4: Video Editor (Cloud Run) ⭐ Pexels 통합
- Phase 5: Quality Checker (Cloud Run)
- Phase 6: Platform Uploader (Cloud Run) ⭐ 멀티 플랫폼
- Phase 7: Analytics Tracker (Cloud Functions)
- Cloud Scheduler 작업 생성 (매일 09:00 자동 실행)

## ✅ 배포 확인

### 1. Cloud Functions 확인

```bash
gcloud functions list --gen2
```

예상 출력:
```
NAME                  REGION            TRIGGER
content-collector     asia-northeast3   Pub/Sub
script-generator      asia-northeast3   Pub/Sub
analytics-tracker     asia-northeast3   HTTP
```

### 2. Cloud Run 서비스 확인

```bash
gcloud run services list
```

예상 출력:
```
SERVICE              REGION            URL
audio-generator      asia-northeast3   https://audio-generator-xxxxx-uc.a.run.app
video-editor         asia-northeast3   https://video-editor-xxxxx-uc.a.run.app
quality-checker      asia-northeast3   https://quality-checker-xxxxx-uc.a.run.app
platform-uploader    asia-northeast3   https://platform-uploader-xxxxx-uc.a.run.app
```

### 3. Cloud Scheduler 확인

```bash
gcloud scheduler jobs list
```

예상 출력:
```
ID                    SCHEDULE      TARGET
daily-content-trigger 0 9 * * *     Pub/Sub: content-trigger
```

## 🎬 첫 영상 생성 테스트

### 수동 트리거

```bash
# 콘텐츠 수집 트리거
gcloud pubsub topics publish content-trigger --message '{}'
```

### 로그 확인

```bash
# Phase 1: 콘텐츠 수집
gcloud functions logs read content-collector --gen2 --limit=20

# Phase 2: 스크립트 생성
gcloud functions logs read script-generator --gen2 --limit=20

# Phase 4: 영상 편집 (Pexels 배경 포함)
gcloud run logs read video-editor --limit=30

# Phase 6: 플랫폼 업로드
gcloud run logs read platform-uploader --limit=30
```

### Firestore에서 결과 확인

```bash
# 웹 콘솔에서 확인
echo "Firestore Console: https://console.cloud.google.com/firestore/data"

# CLI로 확인
gcloud firestore collections documents list trending_topics
gcloud firestore collections documents list scripts
```

**예상 Firestore 데이터**:
```json
{
  "trending_topics": [
    {
      "title": "OpenAI releases GPT-5",
      "score": 5420,
      "source": "reddit",
      "status": "processed"
    }
  ],
  "scripts": [
    {
      "script": "요즘 AI 기술이 정말 빠르게 발전하고 있습니다...",
      "audio_url": "gs://tech-shorts-videos/audio/xxx.mp3",
      "video_url": "https://storage.googleapis.com/tech-shorts-videos/videos/xxx.mp4",
      "upload_results": {
        "youtube": {"video_id": "xxxxx", "video_url": "..."},
        "tiktok": {"publish_id": "xxxxx"},
        "instagram": {"media_id": "xxxxx"}
      },
      "status": "published"
    }
  ]
}
```

## 🔍 문제 해결

### 문제 1: Pexels API 검색 결과 없음

**증상**: 
```
ERROR: Pexels 검색 결과 없음
```

**해결**:
```bash
# .env 파일에서 PEXELS_API_KEY 확인
cat .env | grep PEXELS_API_KEY

# Pexels API 키 테스트
curl -H "Authorization: YOUR_API_KEY" \
  "https://api.pexels.com/videos/search?query=technology&per_page=1"
```

### 문제 2: YouTube 업로드 실패

**증상**:
```
ERROR: YouTube 업로드 실패: 401 Unauthorized
```

**해결**:
1. YouTube Refresh Token 재발급
2. [YouTube OAuth 2.0 Playground](https://developers.google.com/oauthplayground/) 사용
3. `.env` 파일 업데이트 후 재배포

```bash
cd 6-platform-uploader
gcloud run deploy platform-uploader --source .
```

### 문제 3: TikTok 업로드 타임아웃

**증상**:
```
ERROR: TikTok 업로드 타임아웃
```

**해결**:
1. 영상 파일 크기 확인 (최대 500MB)
2. Cloud Run 타임아웃 늘리기

```bash
gcloud run services update platform-uploader \
  --timeout=600s \
  --region=asia-northeast3
```

### 문제 4: Instagram API 오류

**증상**:
```
ERROR: 로컬 파일은 지원되지 않습니다
```

**해결**:
- Instagram은 공개 URL만 지원
- Cloud Storage URL이 `public`인지 확인

```bash
# Cloud Storage 객체 공개 설정
gsutil iam ch allUsers:objectViewer gs://tech-shorts-videos/videos/
```

## 📊 모니터링

### Cloud Monitoring 대시보드

```bash
# GCP 콘솔에서 확인
echo "Cloud Monitoring: https://console.cloud.google.com/monitoring"
```

### 비용 추적

```bash
# 현재까지 비용 확인
gcloud billing accounts list
gcloud billing projects describe $GCP_PROJECT_ID
```

### 영상 생성 통계

```bash
# BigQuery에서 확인
bq query --use_legacy_sql=false \
  'SELECT
     DATE(published_at) as date,
     COUNT(*) as video_count,
     SUM(views) as total_views
   FROM tech_shorts_analytics.video_performance
   GROUP BY date
   ORDER BY date DESC
   LIMIT 30'
```

## 🎉 완료!

이제 시스템이 **매일 09:00에 자동으로**:

1. ✅ Reddit/Hacker News에서 트렌딩 토픽 수집
2. ✅ GPT-4o로 바이럴 스크립트 생성
3. ✅ Google TTS로 한국어 음성 생성
4. ✅ **Pexels에서 배경 영상 자동 다운로드** ⭐
5. ✅ **FFmpeg로 전문가급 영상 편집** ⭐
6. ✅ Gmail로 품질 검수 알림
7. ✅ **YouTube/TikTok/Instagram 자동 업로드** ⭐
8. ✅ BigQuery로 성과 분석

**완전히 자동화된 IT/테크 숏츠 채널이 준비되었습니다!** 🚀

## 📞 추가 도움말

- **GCP 프리티어 한도**: [cloud.google.com/free](https://cloud.google.com/free)
- **YouTube API 할당량**: 일일 10,000 units (충분함)
- **TikTok API 문서**: [developers.tiktok.com/doc](https://developers.tiktok.com/doc)
- **Instagram API 가이드**: [developers.facebook.com/docs/instagram-api](https://developers.facebook.com/docs/instagram-api)

---

**Happy Automating! 🎬✨**
